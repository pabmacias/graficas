THREE.Pathfinding = require('./src');
